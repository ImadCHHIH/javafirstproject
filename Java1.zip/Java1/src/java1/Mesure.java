package java1;

public class Mesure {
	   private int java_id;
	   private int client_id;
	   private double temperature;
	   private double pressure;
	   private double humidity;
	   
	   public Mesure(int java_id, int client_id, double temperature, double pressure, double humidity) {
		super();
		this.java_id = java_id;
		this.client_id = client_id;
		this.temperature = temperature;
		this.pressure = pressure;
		this.humidity = humidity;
	    }

	   public int getJava_id() {
		return java_id;
	   }

	   public void setJava_Id(int java_id) {
		this.java_id = java_id;
	   }

	   public int getClient_id() {
		return client_id;
	   }

	   public void setClient_id(int client_id) {
		this.client_id = client_id;
	    }

	   public double getTemperature() {
		return temperature;
	   }

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public double getPressure() {
		return pressure;
	}

	public void setPressure(double pressure) {
		this.pressure = pressure;
	}

	   public double getHumidity() {
		return humidity;
	   }

	   public void setHumidity(double humidity) {
		this.humidity = humidity;
	   }

	   @Override
	   public String toString() {
		 return "Mesure [java_id=" + java_id + ", client_id=" + client_id + ", temperature=" + temperature
				+ ", pressure=" + pressure + ", humidity=" + humidity + "]";
	   }
	   
	   
	   
	}