package java1;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    private static final int Port = 1234;

    public static void main(String[] args) throws IOException {
        ServerSocket Session = new ServerSocket(Port);
        System.out.println("Server is ON in port : " + Port);

        while (true) {
            Socket s = Session.accept();
            System.out.println("Client is connected ");
            Communication c = new Communication(s);
            c.start();
        }
    }
}