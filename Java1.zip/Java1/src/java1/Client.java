package java1;

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            Socket s = new Socket("localhost", 1234);
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);

            System.out.print("Give a client id : ");
            int client_id = sc.nextInt();

            System.out.print("Give a temperature value : ");
            double temperature = sc.nextDouble();

            System.out.print("Give a pressure value : ");
            double pressure = sc.nextDouble();

            System.out.print("Give a humidity value : ");
            double humidity = sc.nextDouble();

            String message = client_id + ";" + temperature + ";" + pressure + ";" + humidity;

            pw.println(message);

            System.out.println("Mesure sent successfully");

            pw.close();
            s.close();

        } catch (Exception e) {
            System.out.println("Client Error  : " + e.getMessage());
        }

        sc.close();
    }
}