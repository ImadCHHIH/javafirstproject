package java1;

import java.sql.*;
import java.util.Scanner;

public class Operate {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/temperature";
        String user = "root";
        String password = "8185";

        Scanner sc = new Scanner(System.in);
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection(url, user, password);

            int pick;

            do {
                System.out.println("\n--- COMMAND MENU  ---");
                System.out.println("1. All mesures (LIMIT 10)");
                System.out.println("2. All mesures by storing (LIMIT 10)");
                System.out.println("3. Averages (AVG)");
                System.out.println("4. Average by selection");
                System.out.println("5. Exit");
                System.out.print("Pick a command : ");
                pick = sc.nextInt();

                switch (pick) {
                    case 1:
                        afficherLimit10(c);
                        break;

                    case 2:
                        storebyselect(c, sc);
                        break;

                    case 3:
                        average(c);
                        break;

                    case 4:
                        averagebyselect(c, sc);
                        break;

                    case 5:
                        System.out.println("Exiting...");
                        break;

                    default:
                        System.out.println("Invalid pick");
                }

            } while (pick != 5);

            c.close();
            sc.close();

        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
    }

    public static void afficherLimit10(Connection c) throws Exception {
        String sql = "SELECT * FROM java ORDER BY java_id DESC LIMIT 10";
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery(sql);

        System.out.println("\n--- 10 LAST MESURES ---");

        while (rs.next()) {
            System.out.println(
                rs.getInt("java_id") + " | client=" + rs.getInt("client_id") +
                " | Temp=" + rs.getDouble("temperature") +
                " | Pressure=" + rs.getDouble("pressure") +
                " | Humidity=" + rs.getDouble("humidity") +
                " | Date=" + rs.getString("date_mesure")
            );
        }
        rs.close();
        st.close();
    }

    public static void storebyselect(Connection c, Scanner sc) throws Exception {
        System.out.println("\nPick your storing : client_id, temperature, pressure, humidity, date_mesure");
        System.out.print("store by : ");
        String store = sc.next();

        String sql = "SELECT * FROM java ORDER BY " + store + " DESC LIMIT 10";

        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery(sql);

        System.out.println("\n--- Results are stored by " + store + " ---");

        while (rs.next()) {
            System.out.println(
                rs.getInt("java_id") + " | Client=" + rs.getInt("client_id") +
                " | Temp=" + rs.getDouble("temperature") +
                " | Pressure=" + rs.getDouble("pressure") +
                " | Humidity=" + rs.getDouble("humidity") +
                " | Date=" + rs.getString("date_mesure")
            );
        }
        rs.close();
        st.close();
    }

    public static void average(Connection c) throws Exception {
        String sql =
            "SELECT AVG(temperature) AS tempAvg, AVG(pressure) AS presAvg, AVG(humidity) AS humAvg FROM java";

        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery(sql);

        if (rs.next()) {
            System.out.println("\n--- AVERAGES ---");
            System.out.println("Average temperature : " + rs.getDouble("tempAvg"));
            System.out.println("Average pressure    : " + rs.getDouble("presAvg"));
            System.out.println("Average humidity  : " + rs.getDouble("humAvg"));
        }
        rs.close();
        st.close();
    }
    public static void averagebyselect(Connection c, Scanner sc) throws Exception {
        System.out.println("\nPick your storing : temperature, pressure, humidity");
        System.out.print("store by : ");
        String pick = sc.next();

        String sql = "SELECT AVG(" + pick + ") AS avg FROM java";

        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery(sql);

        if (rs.next()) {
            System.out.println("\nThe average of " + pick + " = " + rs.getDouble("avg"));
        }

        rs.close();
        st.close();
    }
private int java_id;
private int client_id;
private double temperature;
private double pressure;
private double humidity;

public Operate(int java_id, int client_id, double temperature, double pressure, double humidity) {
	super();
	this.java_id = java_id;
	this.client_id = client_id;
	this.temperature = temperature;
	this.pressure = pressure;
	this.humidity = humidity;
 }

public int getJava_id() {
	return java_id;
}

public void setJava_Id(int java_id) {
	this.java_id = java_id;
}

public int getClient_id() {
	return client_id;
}

public void setClient_id(int client_id) {
	this.client_id = client_id;
 }

public double getTemperature() {
	return temperature;
}

public void setTemperature(double temperature) {
	this.temperature = temperature;
}

public double getPressure() {
	return pressure;
}

public void setPressure(double pressure) {
	this.pressure = pressure;
}

public double getHumidity() {
	return humidity;
}

public void setHumidity(double humidity) {
	this.humidity = humidity;
}

@Override
public String toString() {
	 return "Mesure [java_id=" + java_id + ", client_id=" + client_id + ", temperature=" + temperature
			+ ", pressure=" + pressure + ", humidity=" + humidity + "]";
}



}