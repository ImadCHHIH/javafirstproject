package java1;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Communication extends Thread {
    private Socket s;

    public Communication(Socket s) {
        this.s = s;
    }
    public void run() {
        String url = "jdbc:mysql://localhost:3306/temperature?serverTimezone=UTC";
        String user = "root";
        String password = "8185";

        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion succeeded");

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(s.getInputStream())
            );

            String line = br.readLine();
            System.out.println("client received : " + line);

            String[] data = line.split(";");

            int client_id = Integer.parseInt(data[0]);
            double temperature = Double.parseDouble(data[1]);
            double pressure = Double.parseDouble(data[2]);
            double humidity = Double.parseDouble(data[3]);

            String sql = "INSERT INTO java(client_id, temperature, pressure, humidity) VALUES (?,?,?,?)";
            PreparedStatement pst = c.prepareStatement(sql);

            pst.setInt(1, client_id);
            pst.setDouble(2, temperature);
            pst.setDouble(3, pressure);
            pst.setDouble(4, humidity);
            pst.executeUpdate();
            System.out.println("Data received");

            pst.close();
            c.close();
            s.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}